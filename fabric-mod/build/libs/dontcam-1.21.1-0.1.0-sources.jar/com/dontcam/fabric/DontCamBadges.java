package com.dontcam.fabric;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_757;
import org.joml.Matrix4f;

/**
 * Shared DC badge helpers + {@code tag.png} icon rendering.
 *
 * <p>Texture lives at {@code assets/dontcam/textures/tag.png} and is referenced
 * as {@code dontcam:textures/tag.png}. All badge/icon rendering is gated on
 * {@link DontCamFabricMod#config}{@code .badges} by the callers.
 */
public final class DontCamBadges {

    /** Small infinity-logo icon drawn before the nickname. */
    public static final class_2960 TAG_TEXTURE = class_2960.method_60655("dontcam", "textures/tag.png");

    private DontCamBadges() {
    }

    /** {@code D}(blue,bold) + {@code C}(aqua,bold) + space + name [+ gold star for the owner]. */
    public static class_5250 badgeLine(class_2561 name, boolean owner) {
        class_5250 line = class_2561.method_43470("D").method_27695(class_124.field_1078, class_124.field_1067)
                .method_10852(class_2561.method_43470("C").method_27695(class_124.field_1075, class_124.field_1067))
                .method_10852(class_2561.method_43470(" "))
                .method_10852(name.method_27661());
        if (owner) {
            line.method_10852(class_2561.method_43470(" \u2605").method_27695(class_124.field_1065, class_124.field_1067));
        }
        return line;
    }

    /** 2D icon for screens / HUD / tab-list overlays. */
    public static void drawTagIcon(class_332 context, int x, int y, int size) {
        try {
            context.method_25290(TAG_TEXTURE, x, y, 0, 0, size, size, size, size);
        } catch (Exception ignored) {
        }
    }

    /**
     * World-space icon for the overhead nametag. Draws a {@code size x size} textured
     * quad on the current label matrix at {@code (x, y)}, then the caller draws text.
     */
    public static void drawTagIconWorld(class_4587 matrices, float x, float y, float size) {
        try {
            class_310 client = class_310.method_1551();
            client.method_1531().method_22813(TAG_TEXTURE);
            RenderSystem.setShader(class_757::method_34542);
            RenderSystem.setShaderTexture(0, TAG_TEXTURE);
            Matrix4f matrix = matrices.method_23760().method_23761();
            class_289 tessellator = class_289.method_1348();
            class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1585);
            buffer.method_22918(matrix, x, y + size, 0.0f).method_22913(0.0f, 1.0f);
            buffer.method_22918(matrix, x + size, y + size, 0.0f).method_22913(1.0f, 1.0f);
            buffer.method_22918(matrix, x + size, y, 0.0f).method_22913(1.0f, 0.0f);
            buffer.method_22918(matrix, x, y, 0.0f).method_22913(0.0f, 0.0f);
            class_286.method_43433(buffer.method_60800());
        } catch (Exception ignored) {
        }
    }
}
