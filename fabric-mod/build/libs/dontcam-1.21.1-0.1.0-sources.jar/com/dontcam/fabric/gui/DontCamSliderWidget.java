package com.dontcam.fabric.gui;

import java.util.function.DoubleConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_357;

/** 0..255 channel slider. Value changes call back live (no disk writes). */
public class DontCamSliderWidget extends class_357 {

    private final String label;
    private final DoubleConsumer onChange;

    public DontCamSliderWidget(int x, int y, int width, String label, int value, DoubleConsumer onChange) {
        super(x, y, width, 20, class_2561.method_43470(label + ": " + value), value / 255.0);
        this.label = label;
        this.onChange = onChange;
    }

    public void setChannel(int value) {
        this.field_22753 = Math.max(0, Math.min(255, value)) / 255.0;
        this.method_25346();
    }

    public int getChannel() {
        return (int) Math.round(this.field_22753 * 255.0);
    }

    @Override
    protected void method_25346() {
        this.method_25355(class_2561.method_43470(label + ": " + getChannel()));
    }

    @Override
    protected void method_25344() {
        if (onChange != null) {
            onChange.accept(this.field_22753);
        }
    }
}
