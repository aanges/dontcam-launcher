package com.dontcam.fabric.gui;

import com.dontcam.fabric.ClientConfig;
import com.dontcam.fabric.DontCamFabricMod;
import com.dontcam.fabric.hud.HudOverlay;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;

/**
 * Per-module color picker: big swatch + R/G/B sliders + HEX field +
 * preset palette + Static/Chroma/Rainbow modes. Everything is live.
 */
public class ColorPickerScreen extends class_437 {

    private static final int[] PRESETS = {
            0xFFFFFF, 0x55FFFF, 0x55FF55, 0xFFFF55,
            0xFF5555, 0x5555FF, 0xFF55FF, 0xAAAAAA,
    };

    private final String id;
    private DontCamSliderWidget sliderR;
    private DontCamSliderWidget sliderG;
    private DontCamSliderWidget sliderB;
    private class_342 hexField;

    public ColorPickerScreen(String id) {
        super(class_2561.method_43470("Color picker"));
        this.id = id;
    }

    private ClientConfig.Module module() {
        ClientConfig cfg = DontCamFabricMod.config;
        if ("cps".equals(id)) {
            return cfg.cps;
        }
        if ("keys".equals(id)) {
            return cfg.keys;
        }
        return cfg.fps;
    }

    private String title() {
        if ("cps".equals(id)) {
            return "CPS color";
        }
        if ("keys".equals(id)) {
            return "Keystrokes color";
        }
        return "FPS color";
    }

    private static int red(int rgb) {
        return (rgb >> 16) & 0xFF;
    }

    private static int green(int rgb) {
        return (rgb >> 8) & 0xFF;
    }

    private static int blue(int rgb) {
        return rgb & 0xFF;
    }

    private static String hex(int rgb) {
        return String.format("%06X", rgb & 0xFFFFFF);
    }

    private void refreshHex() {
        if (hexField != null) {
            hexField.method_1852(hex(module().color));
        }
    }

    @Override
    protected void method_25426() {
        this.method_37067();
        ClientConfig.Module m = module();
        int cx = this.field_22789 / 2;
        int y = this.field_22790 / 2 - 72;

        sliderR = new DontCamSliderWidget(cx - 110, y + 44, 220, "R", red(m.color), v -> {
            m.color = (m.color & 0x00FFFF) | (sliderR.getChannel() << 16);
            refreshHex();
        });
        sliderG = new DontCamSliderWidget(cx - 110, y + 68, 220, "G", green(m.color), v -> {
            m.color = (m.color & 0xFF00FF) | (sliderG.getChannel() << 8);
            refreshHex();
        });
        sliderB = new DontCamSliderWidget(cx - 110, y + 92, 220, "B", blue(m.color), v -> {
            m.color = (m.color & 0xFFFF00) | sliderB.getChannel();
            refreshHex();
        });
        this.method_37063(sliderR);
        this.method_37063(sliderG);
        this.method_37063(sliderB);

        hexField = new class_342(this.field_22793, cx - 110, y + 116, 106, 20, class_2561.method_43470("HEX"));
        hexField.method_1880(7);
        hexField.method_1852(hex(m.color));
        hexField.method_1863(text -> {
            String t = text.startsWith("#") ? text.substring(1) : text;
            if (t.length() == 6) {
                try {
                    int rgb = Integer.parseInt(t, 16) & 0xFFFFFF;
                    m.color = rgb;
                    sliderR.setChannel(red(rgb));
                    sliderG.setChannel(green(rgb));
                    sliderB.setChannel(blue(rgb));
                } catch (NumberFormatException ignored) {
                }
            }
        });
        this.method_37063(hexField);

        this.method_37063(new DontCamButtonWidget(cx + 2, y + 116, 108, 20,
                class_2561.method_43470("Use HEX"),
                b -> refreshHex()));

        // Preset palette row (8 swatches are drawn in render; click zones handled below).
        this.method_37063(new DontCamButtonWidget(cx - 110, y + 140, 68, 20,
                class_2561.method_43470("Static"), b -> setMode("static")));
        this.method_37063(new DontCamButtonWidget(cx - 34, y + 140, 68, 20,
                class_2561.method_43470("Chroma"), b -> setMode("chroma")));
        this.method_37063(new DontCamButtonWidget(cx + 42, y + 140, 68, 20,
                class_2561.method_43470("Rainbow"), b -> setMode("rainbow")));

        this.method_37063(new DontCamButtonWidget(cx - 110, y + 164, 220, 20,
                class_2561.method_43470("Back"),
                b -> {
                    DontCamFabricMod.config.save();
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new ModuleSettingsScreen(id));
                    }
                }));
    }

    private void setMode(String mode) {
        module().colorMode = mode;
        DontCamFabricMod.config.save();
        this.method_41843();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            // Preset swatch click zones (drawn in render below the sliders).
            int cx = this.field_22789 / 2;
            int y = this.field_22790 / 2 - 72;
            for (int i = 0; i < PRESETS.length; i++) {
                int px = cx - 110 + i * 28;
                int py = y + 116 - 24;
                if (mouseX >= px && mouseX < px + 24 && mouseY >= py && mouseY < py + 20) {
                    module().color = PRESETS[i];
                    module().colorMode = "static";
                    DontCamFabricMod.config.save();
                    sliderR.setChannel(red(PRESETS[i]));
                    sliderG.setChannel(green(PRESETS[i]));
                    sliderB.setChannel(blue(PRESETS[i]));
                    refreshHex();
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0x80000000);
        ClientConfig.Module m = module();
        int cx = this.field_22789 / 2;
        int y = this.field_22790 / 2 - 72;

        context.method_25300(this.field_22793, title(), cx, y - 24, 0xFFFFFFFF);

        // Big live swatch (animated for chroma/rainbow).
        int argb = HudOverlay.resolveColor(m);
        context.method_25294(cx - 110, y, cx + 110, y + 36, 0xFF101018);
        context.method_25294(cx - 108, y + 2, cx + 108, y + 34, argb);
        context.method_27534(this.field_22793,
                class_2561.method_43470(modeLabel(m)).method_27694(s -> s.method_36139(0xFF7DD3FC)), cx, y + 12, 0xFFFFFFFF);

        // Preset swatches above the HEX row.
        for (int i = 0; i < PRESETS.length; i++) {
            int px = cx - 110 + i * 28;
            int py = y + 116 - 24;
            context.method_25294(px, py, px + 24, py + 20, 0xFF000000 | PRESETS[i]);
            context.method_25294(px, py, px + 24, py + 1, 0xFF2E9BFF);
            context.method_25294(px, py + 19, px + 24, py + 20, 0xFF2E9BFF);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private static String modeLabel(ClientConfig.Module m) {
        if ("chroma".equals(m.colorMode)) {
            return "CHROMA";
        }
        if ("rainbow".equals(m.colorMode)) {
            return "RAINBOW";
        }
        return "STATIC";
    }

    @Override
    public void method_25432() {
        DontCamFabricMod.config.save();
        super.method_25432();
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
