package com.dontcam.fabric.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/** Rounded button with hover glow, used by DontCam screens. */
public class DontCamButtonWidget extends class_4185 {

    private static final int BG = 0xCC101018;
    private static final int BG_HOVER = 0xFF1B63D6;
    private static final int BORDER = 0xFF2E9BFF;
    private static final int BORDER_DIM = 0x552E9BFF;

    public DontCamButtonWidget(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        boolean hovered = this.method_49606();
        int bg = hovered ? BG_HOVER : BG;
        int border = hovered ? BORDER : BORDER_DIM;
        int x = this.method_46426();
        int y = this.method_46427();
        int w = this.field_22758;
        int h = this.field_22759;
        // body
        context.method_25294(x + 1, y, x + w - 1, y + h, bg);
        context.method_25294(x, y + 1, x + w, y + h - 1, bg);
        // border
        context.method_25294(x + 1, y, x + w - 1, y + 1, border);
        context.method_25294(x + 1, y + h - 1, x + w, y + h, border);
        context.method_25294(x, y + 1, x + 1, y + h - 1, border);
        context.method_25294(x + w - 1, y + 1, x + w, y + h - 1, border);
        if (hovered) {
            context.method_25294(x + 1, y + 1, x + w - 1, y + 3, 0x33FFFFFF);
        }
        int color = this.field_22763 ? 0xFFFFFFFF : 0xFFA0A0A0;
        context.method_27534(
                net.minecraft.class_310.method_1551().field_1772,
                this.method_25369(), x + w / 2, y + (h - 8) / 2, color);
    }
}
