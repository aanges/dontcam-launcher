package com.dontcam.fabric.gui;

import com.dontcam.fabric.ClientConfig;
import com.dontcam.fabric.DontCamFabricMod;
import com.dontcam.fabric.hud.HudOverlay;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Per-module settings: position (sliders + drag on the live preview),
 * scale, text color, background and label toggles.
 */
public class ModuleSettingsScreen extends class_437 {

    private final String id;
    private String dragging;
    private int colorRowY;

    public ModuleSettingsScreen(String id) {
        super(class_2561.method_43470("Module settings"));
        this.id = id;
    }

    private ClientConfig.Module module() {
        ClientConfig cfg = DontCamFabricMod.config;
        if ("cps".equals(id)) {
            return cfg.cps;
        }
        if ("keys".equals(id)) {
            return cfg.keys;
        }
        return cfg.fps;
    }

    private String title() {
        if ("cps".equals(id)) {
            return "CPS";
        }
        if ("keys".equals(id)) {
            return "Keystrokes";
        }
        return "FPS";
    }

    private void stepper(String label, String value, Runnable dec, Runnable inc, int y) {
        int cx = this.field_22789 / 2;
        this.method_37063(new DontCamButtonWidget(cx - 110, y, 24, 20,
                class_2561.method_43470("<"), b -> dec.run()));
        this.method_37063(new DontCamButtonWidget(cx + 86, y, 24, 20,
                class_2561.method_43470(">"), b -> inc.run()));
        rowLabels.add(new String[]{label + ": " + value, String.valueOf(cx), String.valueOf(y + 6)});
    }

    private final java.util.List<String[]> rowLabels = new java.util.ArrayList<>();

    @Override
    protected void method_25426() {
        rowLabels.clear();
        this.method_37067();
        ClientConfig.Module m = module();
        int y = this.field_22790 / 2 - 52;

        stepper("X", String.valueOf(m.x), () -> {
            m.x -= 5;
            DontCamFabricMod.config.save();
            this.method_41843();
        }, () -> {
            m.x += 5;
            DontCamFabricMod.config.save();
            this.method_41843();
        }, y);
        stepper("Y", String.valueOf(m.y), () -> {
            m.y -= 5;
            DontCamFabricMod.config.save();
            this.method_41843();
        }, () -> {
            m.y += 5;
            DontCamFabricMod.config.save();
            this.method_41843();
        }, y + 24);
        stepper("Size", "x" + Math.round(m.scale * 100) / 100.0, () -> {
            m.scale = Math.max(0.5f, m.scale - 0.25f);
            DontCamFabricMod.config.save();
            this.method_41843();
        }, () -> {
            m.scale = Math.min(3.0f, m.scale + 0.25f);
            DontCamFabricMod.config.save();
            this.method_41843();
        }, y + 48);

        int cx = this.field_22789 / 2;
        colorRowY = y + 72;
        this.method_37063(new DontCamButtonWidget(cx - 86, colorRowY, 196, 20,
                class_2561.method_43470("Change color..."),
                b -> {
                    DontCamFabricMod.config.save();
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new ColorPickerScreen(id));
                    }
                }));
        if (!"keys".equals(id)) {
            this.method_37063(new DontCamButtonWidget(cx - 110, y + 96, 108, 20,
                    class_2561.method_43470("Label: " + onOff(m.label)),
                    b -> {
                        m.label = !m.label;
                        DontCamFabricMod.config.save();
                        this.method_41843();
                    }));
            this.method_37063(new DontCamButtonWidget(cx + 2, y + 96, 108, 20,
                    class_2561.method_43470("Back: " + onOff(m.bg)),
                    b -> {
                        m.bg = !m.bg;
                        DontCamFabricMod.config.save();
                        this.method_41843();
                    }));
        } else {
            this.method_37063(new DontCamButtonWidget(cx - 110, y + 96, 220, 20,
                    class_2561.method_43470("Back: " + onOff(m.bg)),
                    b -> {
                        m.bg = !m.bg;
                        DontCamFabricMod.config.save();
                        this.method_41843();
                    }));
        }
        this.method_37063(new DontCamButtonWidget(cx - 110, y + 120, 220, 20,
                class_2561.method_43470("Back"),
                b -> {
                    DontCamFabricMod.config.save();
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new ClientOptionsScreen());
                    }
                }));
    }

    private static String onOff(boolean v) {
        return v ? "\u00A7aON" : "\u00A7cOFF";
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int[] r = HudOverlay.lastRects.get(id);
            if (r != null && mouseX >= r[0] && mouseX <= r[0] + r[2]
                    && mouseY >= r[1] && mouseY <= r[1] + r[3]) {
                dragging = id;
                dragOffX = (int) mouseX - r[0];
                dragOffY = (int) mouseY - r[1];
                return true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    private int dragOffX;
    private int dragOffY;

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null && button == 0) {
            ClientConfig.Module m = module();
            if ("keys".equals(id)) {
                int[] an = HudOverlay.keysAnchor(this.field_22789, this.field_22790, previewModuleAtDrag(m));
                m.x = (int) Math.round(mouseX - dragOffX - (an[0] - m.x));
                m.y = (int) Math.round(mouseY - dragOffY - (an[1] - m.y));
            } else {
                m.x = (int) Math.round(mouseX - dragOffX);
                m.y = (int) Math.round(mouseY - dragOffY);
            }
            m.x = Math.max(-400, Math.min(this.field_22789 + 400, m.x));
            m.y = Math.max(-400, Math.min(this.field_22790 + 400, m.y));
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, dx, dy);
    }

    /** Anchor computed without the current offsets (they are being replaced). */
    private ClientConfig.Module previewModuleAtDrag(ClientConfig.Module m) {
        ClientConfig.Module copy = new ClientConfig.Module();
        copy.enabled = m.enabled;
        copy.x = 0;
        copy.y = 0;
        copy.scale = m.scale;
        copy.color = m.color;
        copy.bg = m.bg;
        copy.label = m.label;
        return copy;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (dragging != null && button == 0) {
            dragging = null;
            DontCamFabricMod.config.save();
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0x80000000);
        // Live preview behind the panel (also refreshes drag rects).
        HudOverlay.drawPreview(context, this.field_22789, this.field_22790, this.field_22793);
        context.method_25300(this.field_22793, title() + " settings",
                this.field_22789 / 2, this.field_22790 / 2 - 78, 0xFFFFFFFF);
        // Color swatch next to the Change button.
        int sw = HudOverlay.resolveColor(module());
        int cx = this.field_22789 / 2;
        context.method_25294(cx - 110, colorRowY, cx - 90, colorRowY + 20, 0xFF101018);
        context.method_25294(cx - 109, colorRowY + 1, cx - 91, colorRowY + 19, sw);
        context.method_27534(this.field_22793,
                class_2561.method_43470("drag the module on screen to move it").method_27694(s -> s.method_36139(0xFF7DD3FC)),
                this.field_22789 / 2, this.field_22790 / 2 + 96, 0xFFFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
        for (String[] row : rowLabels) {
            int rcx = Integer.parseInt(row[1]);
            int ry = Integer.parseInt(row[2]);
            int tw = this.field_22793.method_1727(row[0]);
            context.method_51433(this.field_22793, row[0], rcx - tw / 2, ry, 0xFFFFFFFF, false);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
