package com.dontcam.fabric.gui;

import com.dontcam.fabric.ClientConfig;
import com.dontcam.fabric.DontCamFabricMod;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Transparent in-world menu: "Client Options" with square module tiles.
 * Left-click a tile toggles the module, right-click opens its settings.
 */
public class ClientOptionsScreen extends class_437 {

    private final List<DontCamTileWidget> tiles = new ArrayList<>();

    public ClientOptionsScreen() {
        super(class_2561.method_43470("Client Options"));
    }

    private void addTile(String id, String name, ClientConfig.Module module, int x, int y) {
        DontCamTileWidget tile = new DontCamTileWidget(x, y, 64, name, module,
                button -> {
                    module.enabled = !module.enabled;
                    DontCamFabricMod.config.save();
                });
        tiles.add(tile);
        this.method_37063(tile);
    }

    @Override
    protected void method_25426() {
        tiles.clear();
        this.method_37067();
        int cx = this.field_22789 / 2;
        int y = this.field_22790 / 2 - 40;
        ClientConfig cfg = DontCamFabricMod.config;
        addTile("fps", "FPS", cfg.fps, cx - 104, y);
        addTile("cps", "CPS", cfg.cps, cx - 32, y);
        addTile("keys", "KEYS", cfg.keys, cx + 40, y);
        this.method_37063(new DontCamButtonWidget(cx - 104, y + 76, 100, 20,
                class_2561.method_43470("Reset layout"),
                button -> {
                    DontCamFabricMod.config.resetLayout();
                    this.method_41843();
                }));
        this.method_37063(new DontCamButtonWidget(cx + 4, y + 76, 100, 20,
                class_2561.method_43470("Done"),
                button -> {
                    DontCamFabricMod.config.save();
                    this.method_25419();
                }));
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 1) {
            for (DontCamTileWidget tile : tiles) {
                if (tile.method_25405(mouseX, mouseY)) {
                    String id = tileId(tile);
                    if (id != null && this.field_22787 != null) {
                        this.field_22787.method_1507(new ModuleSettingsScreen(id));
                        return true;
                    }
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    private String tileId(DontCamTileWidget tile) {
        ClientConfig cfg = DontCamFabricMod.config;
        int index = tiles.indexOf(tile);
        return index == 0 ? "fps" : index == 1 ? "cps" : index == 2 ? "keys" : null;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Transparent: dim the world instead of the vanilla dirt background.
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0x80000000);
        context.method_25300(this.field_22793, "Client Options",
                this.field_22789 / 2, this.field_22790 / 2 - 66, 0xFFFFFFFF);
        context.method_27534(this.field_22793,
                class_2561.method_43470("left-click: on/off   right-click: settings").method_27694(s -> s.method_36139(0xFF7DD3FC)),
                this.field_22789 / 2, this.field_22790 / 2 + 46, 0xFFFFFFFF);
        String auth = DontCamFabricMod.localMicrosoft ? "\u00A7aMicrosoft" : "\u00A77Offline";
        context.method_25300(this.field_22793, auth, this.field_22789 / 2, this.field_22790 / 2 + 58, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
