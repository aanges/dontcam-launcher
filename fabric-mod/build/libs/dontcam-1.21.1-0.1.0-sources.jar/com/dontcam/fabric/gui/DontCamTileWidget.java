package com.dontcam.fabric.gui;

import com.dontcam.fabric.ClientConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/** Square toggle tile for one HUD module. Left-click toggles, right-click opens settings. */
public class DontCamTileWidget extends class_4185 {

    private static final int BG = 0xCC101018;
    private static final int BG_HOVER = 0xFF1B63D6;
    private static final int ON = 0xFF3DFF7A;
    private static final int OFF = 0xFFFF5555;

    private final ClientConfig.Module module;
    private final String name;

    public DontCamTileWidget(int x, int y, int size, String name, ClientConfig.Module module, class_4241 onPress) {
        super(x, y, size, size, class_2561.method_43473(), onPress, field_40754);
        this.module = module;
        this.name = name;
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        boolean hovered = this.method_49606();
        int bg = hovered ? BG_HOVER : BG;
        int edge = module.enabled ? ON : OFF;
        int x = this.method_46426();
        int y = this.method_46427();
        int s = this.field_22758;
        context.method_25294(x, y, x + s, y + s, bg);
        // colored state border
        context.method_25294(x, y, x + s, y + 2, edge);
        context.method_25294(x, y + s - 2, x + s, y + s, edge);
        context.method_25294(x, y, x + 2, y + s, edge);
        context.method_25294(x + s - 2, y, x + s, y + s, edge);
        if (hovered) {
            context.method_25294(x + 2, y + 2, x + s - 2, y + 5, 0x33FFFFFF);
        }
        TextRendererHolder.drawCentered(context, name, x + s / 2, y + s / 2 - 8, 0xFFFFFFFF);
        TextRendererHolder.drawCentered(context, module.enabled ? "ON" : "OFF",
                x + s / 2, y + s / 2 + 4, edge);
    }

    /** Tiny indirection so the tile doesn't need a client instance for text. */
    static final class TextRendererHolder {
        static void drawCentered(class_332 context, String text, int x, int y, int color) {
            class_310 client = class_310.method_1551();
            int tw = client.field_1772.method_1727(text);
            context.method_51433(client.field_1772, text, x - tw / 2, y, color, false);
        }
    }
}
