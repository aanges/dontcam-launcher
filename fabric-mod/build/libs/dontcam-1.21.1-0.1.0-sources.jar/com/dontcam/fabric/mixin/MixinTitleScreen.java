package com.dontcam.fabric.mixin;

import com.dontcam.fabric.DontCamBadges;
import com.dontcam.fabric.DontCamFabricMod;
import com.dontcam.fabric.gui.ClientOptionsScreen;
import com.dontcam.fabric.gui.DontCamButtonWidget;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_526;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reworked main menu: two columns — MINECRAFT (vanilla entries) next to
 * DONTCAM (client options, tag status, auth) — under a shared banner.
 */
@Mixin(class_442.class)
public abstract class MixinTitleScreen extends class_437 {

    @Unique
    private int dontcam$leftX;
    @Unique
    private int dontcam$rightX;
    @Unique
    private int dontcam$colY;

    protected MixinTitleScreen(class_2561 title) {
        super(title);
    }

    @Unique
    private void dontcam$addButton(int x, int y, String label, Runnable action) {
        this.method_37063(new DontCamButtonWidget(x, y, 180, 20,
                class_2561.method_43470(label), button -> action.run()));
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void dontcam$replaceButtons(CallbackInfo ci) {
        this.method_37067();
        dontcam$colY = this.field_22790 / 2 - 8;
        dontcam$leftX = this.field_22789 / 2 - 190;
        dontcam$rightX = this.field_22789 / 2 + 10;

        dontcam$addButton(dontcam$leftX, dontcam$colY, "Singleplayer", () -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(new class_526(this));
            }
        });
        dontcam$addButton(dontcam$leftX, dontcam$colY + 24, "Multiplayer", () -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(new class_500(this));
            }
        });
        dontcam$addButton(dontcam$leftX, dontcam$colY + 48, "Options", () -> {
            if (this.field_22787 != null && this.field_22787.field_1690 != null) {
                this.field_22787.method_1507(new class_429(this, this.field_22787.field_1690));
            }
        });
        dontcam$addButton(dontcam$leftX, dontcam$colY + 72, "Quit Game", () -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1592();
            }
        });

        dontcam$addButton(dontcam$rightX, dontcam$colY, "Client Options", () -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(new ClientOptionsScreen());
            }
        });
        dontcam$addButton(dontcam$rightX, dontcam$colY + 24, "Key Binds", () -> {
            dontcam$openVanillaOptions();
        });
        dontcam$addButton(dontcam$rightX, dontcam$colY + 48, "Resource Packs", () -> {
            dontcam$openVanillaOptions();
        });
        dontcam$addButton(dontcam$rightX, dontcam$colY + 72, "Language", () -> {
            dontcam$openVanillaOptions();
        });
    }

    @Unique
    private void dontcam$openVanillaOptions() {
        if (this.field_22787 != null && this.field_22787.field_1690 != null) {
            this.field_22787.method_1507(new class_429(this, this.field_22787.field_1690));
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void dontcam$banner(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        int cx = this.field_22789 / 2;
        // Banner covering the vanilla logo + splash zone.
        context.method_25294(cx - 230, 18, cx + 230, 92, 0xCC0A0A12);
        context.method_25294(cx - 230, 18, cx + 230, 19, 0xFF2E9BFF);
        context.method_25294(cx - 230, 91, cx + 230, 92, 0xFF2E9BFF);
        // tag.png logo left of the title.
        DontCamBadges.drawTagIcon(context, cx - 118, 30, 24);
        context.method_27534(this.field_22793,
                class_2561.method_43470("DontCam Client"), cx + 12, 32, 0xFFFFFFFF);
        String auth = DontCamFabricMod.localMicrosoft ? "\u00A7aMicrosoft" : "\u00A77Offline";
        String line = "DC tag always on  \u2022  " + auth + "  \u2022  v0.1.0";
        int tw = this.field_22793.method_1727(line);
        context.method_51433(this.field_22793, line, cx + 12 - tw / 2, 50, 0xFF7DD3FC, false);
        String ver = "Minecraft " + (this.field_22787 != null && this.field_22787.method_1515() != null
                ? this.field_22787.method_1515() : "1.21.1");
        int vw = this.field_22793.method_1727(ver);
        context.method_51433(this.field_22793, ver, cx + 12 - vw / 2, 64, 0xFF64748B, false);
        // Column headers above each button column.
        context.method_27534(this.field_22793, class_2561.method_43470("MINECRAFT"),
                dontcam$leftX + 90, dontcam$colY - 14, 0xFF7DD3FC);
        context.method_27534(this.field_22793, class_2561.method_43470("DONTCAM"),
                dontcam$rightX + 90, dontcam$colY - 14, 0xFF7DD3FC);
    }
}
