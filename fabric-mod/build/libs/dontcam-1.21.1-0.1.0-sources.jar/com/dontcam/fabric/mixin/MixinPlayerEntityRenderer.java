package com.dontcam.fabric.mixin;

import com.dontcam.fabric.DontCamBadges;
import com.dontcam.fabric.DontCamFabricMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;
import net.minecraft.class_1007;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5250;
import net.minecraft.class_742;

/**
 * Custom nametag for DontCam players: "DC" badge before the nick,
 * gold star for the owner (Microsoft sessions only).
 */
@Mixin(class_1007.class)
public abstract class MixinPlayerEntityRenderer {

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"), cancellable = true)
    private void dontcam$label(class_742 player, class_2561 text, class_4587 matrices,
                               class_4597 vertexConsumers, int light, float tickDelta,
                               CallbackInfo ci) {
        UUID uuid = player.method_5667();
        if (!DontCamFabricMod.isDontCam(uuid)) {
            return;
        }
        ci.cancel();

        boolean owner = DontCamFabricMod.isOwner(uuid);
        class_5250 line = DontCamBadges.badgeLine(text, owner);

        class_310 client = class_310.method_1551();
        class_327 textRenderer = client.field_1772;
        float icon = 8.0f;
        float gap = 2.0f;
        float width = -(textRenderer.method_27525(line) + icon + gap) / 2.0f;

        matrices.method_22903();
        matrices.method_22904(0.0, player.method_17682() + 0.5, 0.0);
        matrices.method_22907(client.method_1561().method_24197());
        matrices.method_22905(-0.025f, -0.025f, 0.025f);
        // Icon first, then text shifted right so they sit side by side.
        DontCamBadges.drawTagIconWorld(matrices, width, -1.0f, icon);
        float textX = width + icon + gap;
        textRenderer.method_30882(line, textX, 0.0f, 0xFFFFFFFF, false,
                matrices.method_23760().method_23761(), vertexConsumers,
                class_327.class_6415.field_33993, 0x80000000, light);
        matrices.method_22909();
    }
}
