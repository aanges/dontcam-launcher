package com.dontcam.fabric.mixin;

import com.dontcam.fabric.DontCamBadges;
import com.dontcam.fabric.DontCamFabricMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_640;

/**
 * Tab-list badges: tag.png icon + "DC" before the nick, gold star for the owner.
 *
 * <p>Text comes from {@code getPlayerName} (vanilla pipeline); the icon is overlaid
 * in {@code render} TAIL with best-effort column layout. All icon work is wrapped
 * so a layout mismatch can never crash the tab list.
 */
@Mixin(class_355.class)
public abstract class MixinPlayerListHud {

    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void dontcam$badge(class_640 entry, CallbackInfoReturnable<class_2561> cir) {
        if (entry == null || entry.method_2966() == null) {
            return;
        }
        UUID uuid = entry.method_2966().getId();
        if (!DontCamFabricMod.isDontCam(uuid)) {
            return;
        }
        cir.setReturnValue(DontCamBadges.badgeLine(cir.getReturnValue(), DontCamFabricMod.isOwner(uuid)));
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void dontcam$tagIcons(class_332 context, int scaledWindowWidth,
                                  class_269 scoreboard, class_266 objective, CallbackInfo ci) {
        try {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null || client.field_1724.field_3944 == null) {
                return;
            }
            List<class_640> entries = client.field_1724.field_3944.method_2880().stream()
                    .limit(80)
                    .toList();
            if (entries.isEmpty()) {
                return;
            }
            // Vanilla lays the tab list out in columns of up to 20 rows. Mirror that
            // loosely: column width 300px capped, rows of 20.
            int cols = (entries.size() + 19) / 20;
            cols = Math.max(1, Math.min(4, cols));
            int colWidth = Math.min(300, scaledWindowWidth / Math.max(1, cols) - 40);
            int totalW = cols * colWidth;
            int x0 = scaledWindowWidth / 2 - totalW / 2;
            int y0 = 20;
            for (int idx = 0; idx < entries.size(); idx++) {
                class_640 entry = entries.get(idx);
                if (entry == null || entry.method_2966() == null) {
                    continue;
                }
                UUID uuid = entry.method_2966().getId();
                if (!DontCamFabricMod.isDontCam(uuid)) {
                    continue;
                }
                int col = idx / 20;
                int row = idx % 20;
                int x = x0 + col * colWidth + 4;
                int y = y0 + row * 9;
                DontCamBadges.drawTagIcon(context, x, y - 1, 8);
            }
        } catch (Exception ignored) {
        }
    }
}
