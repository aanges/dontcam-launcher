package com.dontcam.fabric.hud;

import com.dontcam.fabric.ClientConfig;
import com.dontcam.fabric.DontCamFabricMod;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * FPS / CPS / keystrokes overlay, fully driven by {@link ClientConfig}.
 *
 * <p>{@link #drawModules} is shared between the in-game HUD and the options
 * screen live preview. Every drawn module registers its screen rect in
 * {@link #lastRects} so the options screen can drag modules around.
 */
public class HudOverlay {

    private static final int TEXT_DARK = 0xFF000000;
    private static final int BG_PRESSED = 0xCCFFFFFF;

    /** Module id -> last drawn rect {x, y, w, h}, refreshed on every draw. */
    public static final Map<String, int[]> lastRects = new LinkedHashMap<>();

    public static void init() {
        HudRenderCallback.EVENT.register(HudOverlay::render);
    }

    private static void render(class_332 context, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842
                || (client.method_53526() != null && client.method_53526().method_53536())) {
            return;
        }
        drawModules(context, client.method_22683().method_4486(), client.method_22683().method_4502(),
                client.field_1772, client, false);
    }

    /** Live preview for the options screen (uses live game data, never hides). */
    public static void drawPreview(class_332 context, int width, int height, class_327 tr) {
        class_310 client = class_310.method_1551();
        drawModules(context, width, height, tr, client, true);
    }

    private static void drawModules(class_332 context, int width, int height,
                                    class_327 tr, class_310 client, boolean preview) {
        ClientConfig cfg = DontCamFabricMod.config;
        if (cfg == null) {
            return;
        }
        if (cfg.fps.enabled) {
            String text = cfg.fps.label ? client.method_47599() + " FPS" : String.valueOf(client.method_47599());
            drawTextModule(context, tr, cfg.fps, text, "fps");
        } else {
            lastRects.remove("fps");
        }
        if (cfg.cps.enabled) {
            ClickTracker tracker = ClickTracker.get();
            int left = tracker != null ? tracker.leftCps() : 0;
            int right = tracker != null ? tracker.rightCps() : 0;
            String text = left + " | " + right + (cfg.cps.label ? " CPS" : "");
            drawTextModule(context, tr, cfg.cps, text, "cps");
        } else {
            lastRects.remove("cps");
        }
        if (cfg.keys.enabled) {
            drawKeys(context, width, height, tr, client, cfg.keys);
        } else {
            lastRects.remove("keys");
        }
    }

    private static void drawTextModule(class_332 context, class_327 tr,
                                       ClientConfig.Module m, String text, String id) {        float s = m.scale;
        int w = (int) (tr.method_1727(text) * s);
        int h = (int) (9 * s);
        if (m.bg) {
            context.method_25294(m.x - 2, m.y - 2, m.x + w + 2, m.y + h + 2, bgColor());
        }
        context.method_51448().method_22903();
        context.method_51448().method_46416(m.x, m.y, 0);
        context.method_51448().method_22905(s, s, 1.0f);
        context.method_51433(tr, text, 0, 0, resolveColor(m), false);
        context.method_51448().method_22909();
        lastRects.put(id, new int[]{m.bg ? m.x - 2 : m.x, m.bg ? m.y - 2 : m.y,
                w + (m.bg ? 4 : 0), h + (m.bg ? 4 : 0)});
    }

    /** {x0, y0, totalW, totalH, key, gap, spaceH} for the keystrokes block. */
    public static int[] keysAnchor(int width, int height, ClientConfig.Module m) {
        float s = m.scale;
        int key = (int) (22 * s);
        int gap = Math.max(1, (int) (2 * s));
        int spaceH = (int) (12 * s);
        int totalW = key * 3 + gap * 2;
        int totalH = key * 2 + gap * 2 + spaceH + gap + (int) (12 * s);
        // Bottom-center anchor + user offsets.
        int x0 = width / 2 - totalW / 2 + m.x;
        int y0 = height - 68 + m.y;
        return new int[]{x0, y0, totalW, totalH, key, gap, spaceH};
    }

    private static void drawKeys(class_332 context, int width, int height,
                                 class_327 tr, class_310 client, ClientConfig.Module m) {
        int[] an = keysAnchor(width, height, m);
        int x0 = an[0];
        int y0 = an[1];
        int totalW = an[2];
        int totalH = an[3];
        int key = an[4];
        int gap = an[5];
        int spaceH = an[6];
        float s = m.scale;

        boolean fw = client.field_1690.field_1894.method_1434();
        boolean lf = client.field_1690.field_1913.method_1434();
        boolean bk = client.field_1690.field_1881.method_1434();
        boolean rt = client.field_1690.field_1849.method_1434();
        boolean space = client.field_1690.field_1903.method_1434();
        boolean lmb = client.field_1690.field_1886.method_1434();
        boolean rmb = client.field_1690.field_1904.method_1434();

        keyBox(context, tr, x0 + key + gap, y0, key, key, "W", fw, m);
        keyBox(context, tr, x0, y0 + key + gap, key, key, "A", lf, m);
        keyBox(context, tr, x0 + key + gap, y0 + key + gap, key, key, "S", bk, m);
        keyBox(context, tr, x0 + key * 2 + gap * 2, y0 + key + gap, key, key, "D", rt, m);

        int sy = y0 + key * 2 + gap * 2;
        context.method_25294(x0, sy, x0 + totalW, sy + spaceH, space ? BG_PRESSED : (m.bg ? bgColor() : 0x00000000));

        int my = sy + spaceH + gap;
        int half = (totalW - gap) / 2;
        int mh = (int) (12 * s);
        keyBox(context, tr, x0, my, half, mh, "LMB", lmb, m);
        keyBox(context, tr, x0 + half + gap, my, totalW - half - gap, mh, "RMB", rmb, m);

        lastRects.put("keys", new int[]{x0, y0, totalW, totalH});
    }

    private static void keyBox(class_332 context, class_327 tr,
                               int x, int y, int w, int h, String label,
                               boolean pressed, ClientConfig.Module m) {
        context.method_25294(x, y, x + w, y + h, pressed ? BG_PRESSED : (m.bg ? bgColor() : 0x00000000));
        int color = pressed ? TEXT_DARK : resolveColor(m);
        int tw = tr.method_1727(label);
        float s = m.scale;
        context.method_51448().method_22903();
        context.method_51448().method_46416(x + (w - tw * s) / 2.0f, y + (h - 8 * s) / 2.0f, 0);
        context.method_51448().method_22905(s, s, 1.0f);
        context.method_51433(tr, label, 0, 0, color, false);
        context.method_51448().method_22909();
    }

    /** ARGB text color for a module: static color or animated chroma/rainbow. */
    public static int resolveColor(ClientConfig.Module m) {
        String mode = m.colorMode == null ? "static" : m.colorMode;
        if ("chroma".equals(mode)) {
            return 0xFF000000 | java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 2000L) / 2000.0f, 1.0f, 1.0f);
        }
        if ("rainbow".equals(mode)) {
            return 0xFF000000 | java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 8000L) / 8000.0f, 0.7f, 1.0f);
        }
        return 0xFF000000 | (m.color & 0xFFFFFF);
    }

    private static int bgColor() {
        return 0x80000000;
    }
}
